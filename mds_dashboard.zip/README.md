
# Modern Data Solutions – Sports Prediction Dashboard

This Streamlit app is the frontend for the MDS predictive modeling system. Hosted via Render and connected to live model data.

## Features
- Streamlit-based dashboard
- Realtime updates
- Betting recommendations

## To run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
